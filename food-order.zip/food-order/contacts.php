<html>
    <h1>For more queries please contact below persons</h1>
<table class="tbl-30">
    
    <tr>
        <td>Full Name</td>
        <td>Suhas Devang H K</td>
    </tr>
    <tr>
        <td>Phone Numer</td>
        <td>7406353942</td>
    </tr>
    <tr>
        <td>Email Id</td>
        <td><a href="suhasdevang018@gmail.com">suhasdevang018@gmail.com</a></td>
    </tr>
</table><br><br>
<table class="tbl-30">
    
    <tr>
        <td>Full Name</td>
        <td>Suman Gowda K B</td>
    </tr>
    <tr>
        <td>Phone Numer</td>
        <td>9141851819</td>
    </tr>
    <tr>
        <td>Email Id</td>
        <td><a href="sumangowda111@gmail.com">sumangowda111@gmail.com</a></td>
    </tr>
</table>





</html>