<?php 
//check whether the user is logged i or not
//authorization
if(!isset($_SESSION['user']))//if user sessio is not set
{
    //user is not logged in 
    //redirect to login page with message
    $_SESSION['no-login-message'] = "<div class='error text-center'>Please Login To Access Admin Panel.</div>";
    header('location:'.SITEURL.'admin/login.php');

}
?>