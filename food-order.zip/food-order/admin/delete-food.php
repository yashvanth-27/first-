<?php
//echo "delete food page";
include('../config/constants.php');

if(isset($_GET['id']) && isset($_GET['image_name']))
{
    //echo "processs to delete";

    //1.get id and image name
    $id = $_GET['id'];
    $image_name = $_GET['image_name'];

    //2.remove the image
    if($image_name!="")
    {
        $path = "../images/food/".$image_name;

        $remove = unlink($path);

        if($remove==false)
        {
            $_SESSION['upload']="<div class='error'>Fail To Remove The Image.</div>";
            header('location:'.SITEURL.'admin/manage-food.php');
            die();
        }
    }

    //3.delete food from database
    $sql = "DELETE FROM tbl_food WHERE id = $id";
    $res = mysqli_query($conn,$sql);

    if($res==true)
    {
        $_SESSION['delete'] = "<div class='success'>Food Deleted Successfully.</div>";
        header('location:'.SITEURL.'admin/manage-food.php');

    }
    else
    {
        $_SESSION['delete'] = "<div class='error'>Fail To Delete Food.</div>";
        header('location:'.SITEURL.'admin/manage-food.php');

    }

    //4.redirect to the manage with the session msg

}
else
{
    //redirect to the manage food page 
    //echo "redirect";
    $_SESSION['unauthorize']="<div class='error'>Unauthorized Access.</div>";
    header('location:'.SITEURL.'admin/manage-food.php');
}
?>